// LAB4_BST.c-Lab04-Travis, Stephney
// 
// Code for ELEC278 Lab 4. Bare bones BST code used to do time comparisons.
// You may recognize this as a cut from the Lab 03 solution.


/* --README--------------------------------------------------------------------
Source code used for teaching purposes in course:
ELEC278, Queen's University, Kingston, Fall semester 2020.
This code is provided without warranty of any kind. It is the responsibility
of the user to determine the correctness and the usefulness of this code for
any purpose.

Author:  David F. Athersych, P.Eng.
All rights reserved. This code is intended for students registered in the
course and the semester listed above.

See LICENCE.MD for restrictions on the use of this code.
---------------------------------------------------------------------------- */



#include <stdlib.h>
#include <stdio.h>
#include "bst.h"
#include "bintree.h"
#include "avl.h"

// Your code goes here - addition so that insert to a BST can be done by passing
// a pTree parameter, not a pNode parameter. (See AVL code for a suggestion.)


void insertBST (Key k, void *v, Tree *t)
// Add new data item to tree.  Use two data components - key and actual data -
// to create new node and insert node in appropriate place.
{
	// Check for mistakes, including verification of tree type
	if ((t == NULL) || (t->tt != BST))	return;
        printf("Insert %d into BST\n", k);
	// Check if tree empty - if so, insert first node
	if (t->root == NULL) {
		Node *n = initNode(k, v);
		n->height = 0;
		t->root = n;
	} else	{
		t->root = insertNodeBST(k, v, t->root);
		}
	return;
}//insert()


Node* insertNodeBST(Key k, void *v, Node *root)
// Build new node and insert into (non-empty) tree. Check if insertion has
// created imbalance and rebalance if necessary.
{
	if (root==NULL) {                           //If the input is the first into the tree
		Node *n = initNode(k, v);               //allocate thte memory for the node
		n->height = 0;                          //set height to 0
		return n;
		}
    //if the k is less then the root, insert in the left sub tree
	if (k < root->key) {
		root->leftChild = insertNodeBST(k, v, root->leftChild);
		root->height = calcHeight(root);
	}else if (k > root->key) {                  //if the k is greater then the root, insert in the right sub tree
		root->rightChild = insertNodeBST(k, v, root->rightChild);
		root->height = calcHeight(root);
		}
    //if equal return root
	return root;
}//insertNode()

void inOrderBST(Node* root)
// In order traversal of tree displaying contents
{
	if (root) {
		inOrderBST(root->leftChild);
		printf("%d - ", root->key);
		inOrderBST(root->rightChild);
		}
}//inOrderT()