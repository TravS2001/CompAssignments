// LAB4_AVL.c-Lab04-Travis, Stephney
//
// Code for ELEC278 Lab 4.  Some code has already been implemented.
// You will develop your own code - look for the comments that say:
// "Your code goes here";
//
// HISTORY:
// 140921 - XXX	First release
// 161004 - HF	Some modifications for clarity, bug fixes
// 161025 - DFA	Additional comments; code updates
// 171016 - DFA	Code clean up
// 191003 - DFA Additional comments; added printTree2()
// 200829 - DFA - Extracted generic tree code

/* --README--------------------------------------------------------------------
Source code used for teaching purposes in course:
ELEC278, Queen's University, Kingston, Fall semester 2020.
This code is provided without warranty of any kind. It is the responsibility
of the user to determine the correctness and the usefulness of this code for
any purpose.

Author:  David F. Athersych, P.Eng.
All rights reserved. This code is intended for students registered in the
course and the semester listed above.

See LICENCE.MD for restrictions on the use of this code.
---------------------------------------------------------------------------- */


#include <stdio.h>
#include "bintree.h"
#include "avl.h"


void printTree(Node* root)
// Print representation of tree. We make an assumption, because tree nodes
// actually have pointer to data, not actual data.  So assume that it is a
// pointer to an integer.
{
	printf("{");		// Tree starts with an opening curly bracket
	// then value of root node
	printf("(%d,%d)", root->key, *(int*) root->value);
						// need to cast void pointer actual data type
	printf(",");		// children come next

	// left child. If NULL it will just print two empty braces,
	// otherwise it prints whole left tree.
	if (root->leftChild) {
		printTree(root->leftChild);
	} else
		printf("{}");
	// separate left child from right child
	printf(",");
	// right child. If NULL it will just print two empty braces,
	// otherwise it prints whole right tree.
	if (root->rightChild) {
		printTree(root->rightChild);
	} else
		printf("{}");
	printf("}");	// Tree ends with closing curly bracket
}//printTree()                                               

//=============================================================================
// ALTERNATE IMPLEMENTATION OF PRINTTREE - FOR YOUR REVIEW.
//    YOU MAY IGNORE THIS.

void printTree2(Node* root)
// Print representation of tree. We make an assumption, because tree nodes
// actually have pointer to data, not actual data.  So assume that it is a
// pointer to an integer.
{
	if (root == NULL)	{
		// printing an empty tree
		printf("{}");
	} else	{
		// printing non-empty tree
		printf("{");		// Tree starts with an opening curly bracket
		// then value of root node
		printf("(%ld,%d)", (long) root->key, *(int*) root->value);
							// need to cast void pointer actual data type
		printf(",");		// children come next

		// left child.
		printTree(root->leftChild);
		// separate left child from right child
		printf(",");
		// right child.
		printTree(root->rightChild);
		printf("}");	// Tree ends with closing curly bracket
		}
}//printTree2()
//=============================================================================

int maxint(int a, int b)	{ return (a>=b) ? a : b; }


void insertAVL (Key k, void *v, Tree *t)
// Add new data item to tree.  Use two data components - key and actual data -
// to create new node and insert node in appropriate place.
{
	// Check for mistakes, including verification of tree type
	if ((t == NULL) || (t->tt != AVL))	return;
	//printf("Insert %d into AVL\n", k);
	// Check if tree empty - if so, insert first node
	if (t->root == NULL) {
		Node *n = initNode(k, v);
		n->height = 0;
		t->root = n;
	} else	{
		t->root = insertNodeAVL(k, v, t->root);
		}
	return;
}//insert()


Node* findParentHelper (Key k, Node* root)
// Help find parent of node with key == k. Parameter root is node with
// at least one child (see findParent()).
{
    if ((root->leftChild !=NULL && (root->leftChild->key==k)) || (root->rightChild !=NULL && (root->rightChild->key==k))){ 
    return root;
}
    if(k> root ->key){
        return findParentHelper(k, root->rightChild);
    }
    else {
        return findParentHelper(k, root->leftChild);
    }
  
}//findParentHelper()


Node *findParent(Key k, Node *root)
// 
{
	// Deal with special special cases which could only happen for root
	// of whole tree
	if (root == NULL)	return root;	
	// real root doesn't have parent so we make it parent of itself
	if (root->key == k)	return root;	
	// root has no children
	if ((root->leftChild == NULL) && (root->rightChild == NULL)) 
			return NULL;
	
	// Deal with cases where root has at least one child
	return findParentHelper(k, root);
}//findParent()


Node* rotateRight(Node* root)
// Rotate to right.  Returns new root pointer.
{
	printf("Rotate Right\n");
    
    Node *temp = root->leftChild;
    Node *temp2 = temp->rightChild;    
    
    //make rotation
   
    temp->rightChild = root;
    root->leftChild = temp2;
    //update height values
    root->height = maxint(calcHeight(root->leftChild), calcHeight(root->rightChild))+1;
    temp->height = maxint(calcHeight(temp->leftChild), calcHeight(temp->rightChild))+1;
    
    //return the new root
	return temp;
}//rotateRight()


Node* rotateLeft(Node* root)
// Rotate to left.  Returns new root pointer.
{
	printf("Rotate Left\n");
    
    Node *temp = root->rightChild;
    Node *temp2 = temp->leftChild;
    
    
    //make rotation
   
    temp->leftChild = root;
    root->rightChild = temp2;
    //update height values
    root->height = maxint(calcHeight(root->leftChild), calcHeight(root->rightChild))+1;
    temp->height = maxint(calcHeight(temp->leftChild), calcHeight(temp->rightChild))+1;

    //return the new root
	return temp;
}//rotateLeft()


int	getBalanceFactor(Node* root)
// Get balance factor - difference between left height and right height
{
	int	hr = -1, hl = -1;		// Default values

    hl = calcHeight(root->leftChild)+hl;
    hr = calcHeight(root->rightChild)+hr;
    
	return hl - hr;
}//getBalanceFactor()


int calcHeight(Node* root)
// Calculate height of this node by adding 1 to maximum of left, right
// child height.
{
	int hrl = -1, hll = -1;		// Default values

    if (root != NULL){
        hll = calcHeight(root->leftChild);              //get height of left subtree
        hrl = calcHeight(root->rightChild);             //get height of right subtree
        return (maxint(hrl,hll)+1);                     //get max of both subtrees and add one
    }
    return -1;
}//calcHeight();


Node* rebalance(Node* root)
// Check balance factor to see if balancing required (bf > 1 or bf < -1).
// If balancing required, perform necessary rotations.
{
	int bf = getBalanceFactor(root);                        //get the value for the balance factor
   
    // right right case
    if (bf > 1 && getBalanceFactor(root->leftChild) >= 0)       
    {
        return rotateRight(root); 
    }
    //Left right case
    if (bf > 1 && getBalanceFactor(root->leftChild) < 0) 
    { 
        root->leftChild =  rotateLeft(root->leftChild); 
        return rotateRight(root); 
    } 
    //right right case
	if (bf < -1 && getBalanceFactor(root->rightChild) <= 0)
    {
        return rotateLeft(root); 
    }
    //right left case
    if (bf < -1 && getBalanceFactor(root->rightChild) > 0) 
    { 
        root->rightChild = rotateRight(root->rightChild); 
        return rotateLeft(root); 
    }
    return root;
}//rebalance()


Node* insertNodeAVL(Key k, void *v, Node *root)
// Build new node and insert into (non-empty) tree. Check if insertion has
// created imbalance and rebalance if necessary.
{
	if (root==NULL) {
		Node *n = initNode(k, v);
		n->height = 0;
		return n;
		}
	if (k < root->key) {
		root->leftChild = insertNodeAVL(k, v, root->leftChild);
		root->height = calcHeight(root);
	} else if (k > root->key) {
		root->rightChild = insertNodeAVL(k, v, root->rightChild);
		root->height = calcHeight(root);
		}
	// Note - ignored equal case - should not occur.
	return rebalance(root);
}//insertNode()


void inOrderT(Node* root)
// In order traversal of tree displaying contents
{
	if (root) {
		inOrderT(root->leftChild);
		printf("%d(h=%d,bf=%d) - ", root->key, root->height,getBalanceFactor(root));
		inOrderT(root->rightChild);
		}
}//inOrderT()

Node* delete(Node* root, Key key){
   
    if (root==NULL) return root;                //if tree is empty then return
   
    if ((root->key)>key){                       //Recursively calls function for left or right subtree until desired not is found
        root->leftChild=delete(root->leftChild, key);
    }
    else if ((root->key)<key){
    root->rightChild=delete(root->rightChild, key);
    }
    else{                                       //node found
        if(root->leftChild==NULL){              //if no leftchild
            Node *temp=root->rightChild;        //create temporary node
            free(root);                         //free delete node
            return temp;                        //return temporary node
        }
        else if (root->rightChild==NULL){       //if no right child
            Node *temp=root->leftChild;         //create temporary node
            free(root);                         //free delete node
            return temp;                        //return temporary node
        }
        Node *temp=root->rightChild;            // set temp to the right child of the root
        while ((temp&&temp->leftChild)!=NULL){  //if temp and temps left child dont equal null
            temp=temp->leftChild;               //loop until the left most child of temp is found
        }
        root->key=temp->key;                    //set new node data to deletion node data
        root->rightChild=delete(root->rightChild, temp->key);   //Recursively call delete. This case applies when two children
    }
    if (root==NULL) return root;
    //update height
    root->height = maxint(calcHeight(root->leftChild), calcHeight(root->rightChild))+1;
    return rebalance(root);    //return rebalanced tree
}