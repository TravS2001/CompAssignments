
public interface Payable {

}
